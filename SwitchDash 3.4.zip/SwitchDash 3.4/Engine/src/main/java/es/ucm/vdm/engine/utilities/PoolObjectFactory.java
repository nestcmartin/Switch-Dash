package es.ucm.vdm.engine.utilities;

public interface PoolObjectFactory<T> {

    public T createObject();

}