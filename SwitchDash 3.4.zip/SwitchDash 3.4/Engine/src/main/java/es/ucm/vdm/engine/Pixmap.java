package es.ucm.vdm.engine;

public interface Pixmap {

    public int getWidth();
    public int getHeight();

    public void dispose();
}